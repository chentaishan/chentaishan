import{_ as s,c as t,o as a,h as o}from"./index-CaNwwWf7.js";const e=s({data:()=>({}),methods:{}},[["render",function(s,e,n,r,d,c){const f=o;return a(),t(f)}]]);export{e as default};
