import{_ as s,c as t,o as a,h as o}from"./index-CIn_CI3p.js";const e=s({data:()=>({}),methods:{}},[["render",function(s,e,n,r,d,c){const f=o;return a(),t(f)}]]);export{e as default};
